var myApp = new Framework7();

         var $$ = Dom7;

         $$('.open-first').on('click', function(){
           myApp.swipeoutOpen('li.swipeout:first-child');
         });
         $$('.open-second').on('click', function(){
           myApp.swipeoutOpen($$('li.swipeout').eq(1));
           setTimeout(function () {
             myApp.swipeoutClose($$('li.swipeout').eq(1));
           }, 1000);
         });
         $$('.delete-last').on('click', function(){
           myApp.swipeoutDelete('li.swipeout:last-child');
         });
 
var $$ = Dom7;
 
$$('.action1').on('click', function () {
  myApp.alert('Action 1');
});
$$('.action2').on('click', function () {
  myApp.alert('Action 2');
});  

var myApp = new Framework7({
    domCache: true
});
var mainView = myApp.addView('.view-main')          
// Load about page:
mainView.router.load({pageName: 'fav'});