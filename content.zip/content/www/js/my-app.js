// Initialize app
var myApp = new Framework7();


// If we need to use custom DOM library, let's save it to $$ variable:
var $$ = Dom7;

// Add view
var mainView = myApp.addView('.view-main', {
    // Because we want to use dynamic navbar, we need to enable it for this view:
    dynamicNavbar: true
});
function editprofile() {
	window.location.href="Edit_profile.html";
	
}
function pagenaviation(pagename) {
	//alert(pagename);
	window.location.href=pagename;
	
}
// Handle Cordova Device Ready Event
$$(document).on('deviceready', function() {
	//window.location.href="Edit_profile.html";
    console.log("Device is ready!");
		// Tag Manager
		var tagManager = cordova.require('com.jareddickson.cordova.tag-manager.TagManager');
		//var trackingId = 'GTM-W9LBQGP'; // My account
		var trackingId = 'GTM-KR3SK5T'; // My account
		//var trackingId = 'GTM-58FM5GD'; // Live account
        var intervalPeriod = 30; // seconds
        // Initialize Tag Manager
		tagManager.init(function() { 
			//alert('init success'+JSON.stringify(tagManager));
        }, null, trackingId, intervalPeriod);

        tagManager.trackPage(function() {
           // alert("trackPage success");
        }, function(){
           // alert("trackPage fail")
        }, '/pocStatusBar');
		
		MCEPlugin.getRegistrationDetails(function(details) {
			//$('#userId').html(details['userId']);
			//$('#channelId').html(details['channelId']);
		//	 MCEPlugin.phoneHome();
		//	alert("userid"+details['userId']);
			//var attribute = "Email";
			//var value = "venkatesh.g@hotcourses.co.in";
		//	var json = {};
		//	json[attribute] = value;
			//json['userId'] = details['userId'];
			//json['channelId'] = details['channelId'];
			
			//var json={"Email":"test@test.com",'userId':details['userId'],'channelId':details['channelId']}
			//alert("device ready");
			
		/*	MCEPlugin.updateUserAttributes(json, function() {
					alert("set user attribute success");
				}, function(error) {
					console.log("attribute failure")
				});*/
			/*if(details['userId']=="DXfz1pt792JJgLja") {
				MCEPlugin.setChannelAttributes(json, function() {
					alert("set attribute success");
				}, function(error) {
					alert("attribute failure")
				});
				
				MCEPlugin.setUserAttributes(json, function() {
					alert("set user attribute success");
				}, function(error) {
					console.log("attribute failure")
				});
			}*/
			
			
			
			/*
			MCEPlugin.updateChannelAttributes(json, function() {
				alert("update attribute success");
			}, function(error) {
				alert("attribute failure")
			});
			*/
			
			
		/*	MCEPlugin.addEvent({ type: "simpleNotification", name: "appOpened", timestamp: new Date() }, function() {
				alert("event success");
			}, function() {
				alert("event failure");
			});*/
			//{"channel" : "mobile","identifiers" : [{"name" : "userId","value" : "ub0N4DZ5678NW" }],"events": [{"code" : "application/installed","timestamp" : ,"attributes" : [{"name" : "eventName","value" : "App Install","type" : "string"},{"name" : "appKey","value" : "121779A453","type" : "string"},{"name" : "channelId","value" : "MB10074354692","type" :"string"},{"name" : "description","value" : "Front of the Line Tix app","type" : "string"}]}]}
			
			
			//{ mobileUserId: details['userId'], channelId: details['channelId'], attribution: "test",appKey:"apPoc5a1Tl",pushType:"simple",actionTaken:"url",customData1:"test",latitude:"",longitude:"" }
			
			//{"channel" : "mobile","identifiers" : [{"name" : "userId","value" : details['userId'] }],"events": [{"code" : "application/installed","timestamp" : new Date(),"attributes" : [{"name" : "eventName","value" : "App Install","type" : "string"},{"name" : "appKey","value" : "apPoc5a1Tl","type" : "string"},{"name" : "channelId","value" : details['channelId'],"type" :"string"},{"name" : "description","value" : "test desc app","type" : "string"}]}]}
			
			//{"events":[{"eventTypeCode":95,"eventTimestamp": new Date() ,"channel":{"channelType":"simple","qualifier":"apPoc5a1Tl","destination":details['userId']+"|"+details['channelId']},"attributes":[{"name":"mobileUserId","value":details['userId']},{"name":"channelId","value":details['channelId']},{"name":"appKey","value":"apPoc5a1Tl"},{"name":"attribution","value":null},{"name":"latitude","value":null},{"name":"longitude","value":null},{"name":"actionTaken","value":"inbox"},{"name":"customData1","value":"should be in customData1"},{"name":"customData2","value":"should be in customData2"},{"name":"customData3","value":"should be in customData3"},{"name":"otherCustomData","value":"should be in otherCustomData"}]}]}

			
			// working code
			//{ type: "Custom", name: "subscribedToComments", timestamp: new Date(), mobileUserId: details['userId'], channelId: details['channelId'], attribution: "attribution",appKey:"apPoc5a1Tl",pushType:"simpleNotification",actionTaken:"urlClicked",customData1:"customData1",latitude:null,longitude:null }
			
			
			
			/*MCEPlugin.addEvent({ type: "custom", name: "read", timestamp: new Date(), pushType:"simple",actionTaken:"read",attribution: "whatuni",customData1:"customData1",latitude:null,longitude:null }, function() {
				alert("custom event success");
			}, function() {
				alert("custom event failure");
			});*/
			
			/*MCEPlugin.addEvent({ type: "custom", name: "new", timestamp: new Date(),customData1:"MyProduct", customData2:"English",latitude:null,longitude:null }, function() {
				alert("new custom event success");
			}, function() {
				alert("new custom event failure");
			});*/
			
			//alert("end");
			});
	
		
		//alert("end");
	
		
});
function updateEmail() {
	var Email = $$("#email").val();
	if(Email!="") {
		var attribute = "Email";
		var value = Email.toLowerCase();
		var json = {};
		json[attribute] = value;
		
		MCEPlugin.updateUserAttributes(json, function() {
			$$("#email").val("");
			myApp.alert("User Email updated successfully","");
		}, function(error) {
			myApp.alert("Failed","");
		});
	} else {
		myApp.alert('Enter Email Address', '');
	}
	
}
function customevent() {
	var actionTaken = $$("#actionTaken").val();
	var customData1 = $$("#customData1").val();
	var customData2 = $$("#customData2").val();
	var customData3 = $$("#customData3").val();
	var otherCustomData = $$("#otherCustomData").val();
	
	
	//alert(actionTaken+" - "+customData1+" - "+attribution);
	//if(actionTaken!="" && customData1!="" && attribution!="" ) {
		//MCEPlugin.getRegistrationDetails(function(details) {
			//alert(customData1);
			MCEPlugin.addEvent({ timestamp: new Date(),type: "custom", name: actionTaken, customData1:customData1,customData2:customData2,customData3:customData3,otherCustomData:otherCustomData}, function() {
				alert("custom event success");
			}, function() {
				alert("custom event failure");
			});
		//});
	//}
}
function simpleEvent() {
		MCEPlugin.addEvent({ type: "simpleNotification", name: "urlClicked", timestamp: new Date() }, function() {
			alert("event success");
		}, function() {
			alert("event failure");
		});
	
}
function statusbar() {
	
		
	
    //StatusBar.overlaysWebView(false);
	var funcolor=$$("#color").val();
	var funcolortext="";
	if(funcolor=="styleDefault") {
		StatusBar.styleDefault();
		funcolortext="Black";
	}
	if(funcolor=="styleLightContent") {
		StatusBar.styleLightContent();
		funcolortext="White";
	}
	if(funcolor=="styleBlackTranslucent")
		StatusBar.styleBlackTranslucent();
	if(funcolor=="styleBlackOpaque")
		StatusBar.styleBlackOpaque();
	
	//StatusBar.overlaysWebView(false);
	var funbgcolor=$$("#bgcolor").val();
	if(funbgcolor!="")
		StatusBar.backgroundColorByName(funbgcolor);
	
	// Tag Manager
		var tagManager = cordova.require('com.jareddickson.cordova.tag-manager.TagManager');
		//var trackingId = 'GTM-W9LBQGP'; // My account
		var trackingId = 'GTM-KR3SK5T'; // My account
		//var trackingId = 'GTM-58FM5GD'; // Live account
        var intervalPeriod = 30; // seconds
        // Initialize Tag Manager
		tagManager.init(function() { 
			//alert('init success'+JSON.stringify(tagManager));
        }, null, trackingId, intervalPeriod);
		
		tagManager.trackEvent(function(){
			//alert("trackevent success");
		}, null, 'statusbarchanged', 'Clicked', 'color : '+funcolortext+' and backgroundcolor : '+funbgcolor, -1);
		
	
			
			
			
			
			
		// push a variable onto the Data Layer
		//tagManager.pushEvent(function(){ alert('push event success'); }, function(){}, {'event interaction type': 'variable_value'});
		
		
	//alert(funcolor);
	//alert(funbgcolor);
}
function statusbarvisible() {
    if (StatusBar.isVisible) {
        // do something
        StatusBar.hide();
        $("#button_visible").html("Show StatusBar");
    } else {
        StatusBar.show();
        $("#button_visible").html("Hide StatusBar");        
    }
}

// Now we need to run the code that will be executed only for About page.

// Option 1. Using page callback for page (for "about" page in this case) (recommended way):
myApp.onPageInit('about', function (page) {
    // Do something here for "about" page
    
})

// Option 2. Using one 'pageInit' event handler for all pages:
$$(document).on('pageInit', function (e) {
    // Get page data from event data
    var page = e.detail.page;

    if (page.name === 'about') {
		//myApp.alert("my about");
		// Tag Manager
		var tagManager = cordova.require('com.jareddickson.cordova.tag-manager.TagManager');
		//var trackingId = 'GTM-W9LBQGP'; // My account
		var trackingId = 'GTM-KR3SK5T'; // My account
		//var trackingId = 'GTM-58FM5GD'; // Live account
        var intervalPeriod = 30; // seconds
        // Initialize Tag Manager
		tagManager.init(function() { 
			//alert('init success'+JSON.stringify(tagManager));
        }, null, trackingId, intervalPeriod);

        tagManager.trackPage(function() {
            //alert("trackPage success");
        }, function(){
            //alert("trackPage fail")
        }, '/pocGoogleMap');
		
		
        // Following code will be executed for page with data-page attribute equal to "about"
        //myApp.alert('Here comes About page');
    }
})

// Option 2. Using live 'pageInit' event handlers for each page
$$(document).on('pageInit', '.page[data-page="about"]', function (e) {
    // Following code will be executed for page with data-page attribute equal to "about"
   // myApp.alert('Here comes About page');
   myApp.closePanel();
})
$$(document).on('pageInit', '.page[data-page="index"]', function (e) {
    // Following code will be executed for page with data-page attribute equal to "about"
   // myApp.alert('Here comes About page');
   myApp.closePanel();
})

$$(document).on('click', '#test', function (e) {
    var platform = device.platform.toLowerCase();
    var scheme ="";
    if(platform == "android") {
         scheme = 'com.google.android.apps.maps';
    } else if(platform == "ios") {
         scheme = 'maps://';
    } else {
        scheme = 'comgooglemaps';
    }
    
    appAvailability.check(
        scheme,       // URI Scheme or Package Name 
        function() {  // Success callback 
            var addressLongLat = '53.22921909999999,-4.129498000000012';
            var addressLongLat = '53.22921,-4.12949';
            if(platform == "android") {
                window.open("geo:"+addressLongLat+"?q="+addressLongLat);
            } else if(platform == "ios") {
                var mapLocationUrl = 'http://maps.apple.com/?q='+addressLongLat+'&ll='+addressLongLat;
				var mapLocationUrl = 'http://maps.apple.com/?q=Bangor university@'+addressLongLat+"&ll="+addressLongLat+"&z=1";
               // var ref = window.open(encodeURI(mapLocationUrl), '_system', 'location=no');
                window.open(encodeURI(mapLocationUrl), '_system');
                //window.open("http://maps.apple.com/?ll="+addressLongLat, '_system');
            }
        },
        function() {  // Error callback 
            var addressLongLat = $(this).attr('lat')+','+$(this).attr('lng');
            var addressLongLat = '53.22921909999999,-4.129498000000012';
            var addressLongLat = '53.22921,-4.12949';
            window.open("http://maps.google.com/?q="+addressLongLat, '_system');
        }
    );
})

