var myApp = new Framework7();
var $$ = Dom7;
var mainView = myApp.addView('.view-main', {
    // Because we want to use dynamic navbar, we need to enable it for this view:
    dynamicNavbar: false
});
function index() {
	window.location.href="index.html";
}
function sortable_test() {
			console.log("sortable");
			$("#sortable-1").sortable({
				scroll: true,
				//scrollSensitivity: 10,
				//scrollSpeed: 40,
				items: '> .slct_f5'
				, axis: "y"
				, delay: 0
				//, distance: 5
				, start: function (e, ui) {
					console.log("sortable start");
					sortable=true;
					ui.helper.addClass('highlight');
					$('.slct_f5').removeClass('swipeout');
					$('.swipeout-actions-right').css('display','none')
				}
				, beforeStop: function (e, ui) {
					sortable=false;
					ui.helper.removeClass('highlight');
					$('.slct_f5').addClass('swipeout');
					$('.swipeout-actions-right').css('display','flex');
					$("#sortable-1").sortable('disable');
					clearTimeout(this.downTimer);
					touch = false;
					var count=1;
					console.log("beforeStop");
					/*$("#sortable-1 li").each(function() {
						var test =$(this);
						angular.forEach($scope.final5,function(value,key){
							//console.log("came");
							if(test.attr('custom_id')==value.id) {
								//console.log("came : "+value.id);
								value.rank=count;
								count = count+1;
							}
						});
						$scope.$apply();
					});*/
				}
			, }).disableSelection();
			$("#sortable-1").sortable('disable');
			
			
		}
angular.module("final5App", []).
controller('final5Controller',function($scope){
	//alert('test')
	$scope.final5=[
		{"id":1,"name":"Law LLB Hons","image_name":"img/unis/Logos/logo_huddersfield.png","college":"Kings College University of London","percentage":"75","rank":"1"},
		{"id":2,"name":"Law LLB Hons","image_name":"img/unis/Logos/logo_kingscollege.png","college":"Nottingham Trent University","percentage":"75","rank":"2"},
		{"id":3,"name":"Law LLB Hons","image_name":"img/unis/Logos/logo_teeside.png","college":"Aston University","percentage":"70","rank":"3"},
		{"id":4,"name":"Law LLB Hons","image_name":"img/unis/Logos/logo_huddersfield.png","college":"Kings College University of London","percentage":"75","rank":"4"},
		{"id":5,"name":"Law LLB Hons","image_name":"img/unis/Logos/logo_kingscollege.png","college":"Nottingham Trent University","percentage":"75","rank":"5"}
	];
	$scope.delete_function = function(delete_id) {
		console.log("deleted called"+delete_id)
		var delete_key = "";
		angular.forEach($scope.final5,function(value,key){
			//console.log("came");
			if(delete_id==value.id) {
				delete_key = key;
			}
		});
		console.log(delete_key)
		$scope.final5.splice(delete_key, 1);
		
		
		console.log("final5");
		console.log($scope.final5);
		setTimeout(function() {
			//sortable_test();
		},500);
		 /*setTimeout(function(){
			var count=1;
			 $("#sortable-1 li").each(function() {
				var test =$(this);
				angular.forEach($scope.final5,function(value,key){
					//console.log("came");
					if(test.attr('custom_id')==value.id) {
						//console.log("came : "+value.id);
						value.rank=count;
						count = count+1;
					}
				});
				$scope.$apply();
			});
			 
		 },500)*/
		 
		
	}
	
	$(function () {
		
		
		var sortable=false;
        
		sortable_test();
				
		

		var touch = false;
		$('.slct_f5').on('touchstart', function(e) {
			if(touch == false && $('.final15').scrollTop()>=0) {
				_this = $(this);
				var _e = e;
				
				this.downTimer = setTimeout(function() {
					_this.addClass('highlight');
					$('#sortable-1').sortable('enable');
					
					touch = true;
					_this.trigger(_e);
				}, 100);
			} else {
				clearTimeout(this.downTimer);
			}
		});
		$('.slct_f5').on('touchend', function(e) {
			clearTimeout(this.downTimer);
			touch = false;
		});
		$('.slct_f5').on('touchmove', function(e) {
			clearTimeout(this.downTimer);
			touch = false;
		});
		$$('.final15').on('scroll', function(e) {   
			//$$("#test").html("scroll"+$(this).scrollTop())
			//touch = true;
			//setTimeout(function(){
			//	touch = false;
			//},200);
		});



    });
});
 