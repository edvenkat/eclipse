function setIcon() {
    window.MobilePush.setIcon("@android:drawable/ic_menu_save");
}


function showXID() {
	window.MobilePush.getXid(function onSucess(xid) {
		console.log("XtifySDK getXid "+xid);
        document.getElementById("content").innerHTML=xid;
//		$("#content").html(xid);
	}, function onError(error) {
		console.log("XtifySDK getXid "+error);
//		$("#content").html("Error: "+error);
        document.getElementById("content").innerHTML=error ;
	});
}


function showInbox() {
	window.MobilePush.getRichNotifications(true, function onSucess(notifications) {
		if(notifications != null && typeof notifications != "undefined" && notifications.length >0) {
			var cnt = "<TABLE><TR><TD>Date</TD><TD>Subject</TD><TD>Show</TD><TD>Delete</TD></TR>";
			var i;
			for(i=0;i<notifications.length;++i) {
				var highlight="";
				if(notifications[i].unread) {
					highlight="<B>";
				}
				cnt+="<TR>";
				cnt+="<TD>"+highlight+notifications[i].receiveDate+"</TD>";
				cnt+="<TD>"+highlight+notifications[i].subject+"</TD>";
				cnt+="<TD><a href=\"javascript:showMsg('"+notifications[i].messageId+"')\">Show</A></TD>";
				cnt+="<TD><a href=\"javascript:removeMsg('"+notifications[i].messageId+"')\">Delete</A></TD>";
				cnt+="</TR>";				
			}
			cnt+="</TABLE>";
//			$("#content").html(cnt);
        document.getElementById("content").innerHTML=cnt;
			window.MobilePush.addMetric(window.MobilePush.metricType.inboxClicked, null);
		} else {
//			$("#content").html("No messages");
        document.getElementById("content").innerHTML="No messages";
		}
		
	});
}

function showMsg(mid) {
	window.MobilePush.getRichNotification(mid, function onSucess(notification) {
//		$("#content").html(notification.message);
        document.getElementById("content").innerHTML=notification.message ;
		if(notification.unread) {
			window.MobilePush.setRichNotificationUnreadFlag(mid, false);
		}
		window.MobilePush.addMetric(window.MobilePush.metricType.richDisplayed, notification.messageId);
	} );
}

function showUnreadMsg(mid) {
// Show the rich message mid only if it is unread.
// Useful when doing the check for new messages.
       console.log("showUnreadMsg " + mid);
       window.MobilePush.getRichNotification(mid, function onSucess(input) {
       var notification = eval(input);
		console.log("rich:"+notification);
		console.log("rich notif: "+JSON.stringify(notification));
//		$("#content").html(notification.message);
		if(notification.unread) {
		    document.getElementById("content").innerHTML=notification.message ;
		    window.MobilePush.setRichNotificationUnreadFlag(mid, false);
		    window.MobilePush.addMetric(window.MobilePush.metricType.richDisplayed, notification.messageId);
		}
	} );
}

function showSimpleMsg(notification) {
    console.log("showSimpleMsg");
    var message  = notification.message;
    var subject = " ";
    if (exists(notification.subject)) // Android only
        message =notification.message;
    var substituteHtml = "<pre>" + subject +" "+ message + "</pre>";
    document.getElementById("content").innerHTML=substituteHtml;
}

function removeMsg(mid) {
	console.log("removeMsg() removing message "+mid);
	window.MobilePush.removeRichNotification(mid, function onSucess() {
		console.log("XtifySDK remove message "+mid);
//		$("#content").html("Message removed");
         document.getElementById("content").innerHTML="Message: "+mid+" remved" ;
	});
}

function showLastNotification() {
	window.MobilePush.getIncomingNotification(function onSucess(notification) {
		console.log("XtifySDK last notification "+JSON.stringify(notification));
//		$("#content").html(JSON.stringify(notification));
          document.getElementById("content").innerHTML=JSON.stringify(notification) ;
        }, function onError(error) {
        console.log("showLastNotification"+error);
//        $("#content").html("showLastNotification Error: "+error);
             document.getElementById("content").innerHTML="show last notification error" ;
        });
}

function addTag(tag) {
	window.MobilePush.addTag(tag );
    console.log("Retrun from addTag");
}

function unTag(untag) {
	window.MobilePush.unTag(untag);
    console.log("Retrun from unTag");
}

function getBadge() {
	window.MobilePush.getBadge(function onSucess(input) {
//                               $("#content").html('Badge:'+input);
                               document.getElementById("content").innerHTML="Bedge:"+input ;
                               }, function onError(error) {
                               console.log("ERROR getBadge "+error);
//                               $("#content").html("Error: "+error);
                               document.getElementById("content").innerHTML=error ;
                               });
}
function setBadge(badge) {
    window.MobilePush.setBadge(badge, function onSucess(input) {
                               console.log("Set badge to"+badge);
//                               $("#content").html('Badge:'+input);
                               document.getElementById("content").innerHTML="Bedge:"+input;
                               }, function onError(error) {
                               console.log("ERROR setBadge "+error);
//                               $("#content").html("Error: "+error);
                               document.getElementById("content").innerHTML=error;
                               });

}

function setLocationOn() {
	window.MobilePush.setLocationUpdateEnabled(true);
    console.log("Enabled Location Update");
}

function exists(variable) {
	return (typeof variable != 'undefined' && variable != null); 
};
// Utility method to see if a message has arrived
function checkForMessages() {
           console.log("checkForMessages ");
           window.MobilePush.getIncomingNotification(function onSucess(notification) {
	       if (notification != null) {
	    	   if (notification.action == null) {
			       // Ignore empty notifications
			       return;
			   }
		   if (notification.action.type.toUpperCase() == "RICH") {
	    // Got a rich notification and open it
			  var messageId = notification.action.data;
			  console.log("checkForMessages richid: "+messageId);
			  window.MobilePush.getRichNotifications(true, function onSucess(notifications) {
			    showMsg(messageId);
			  });
		     } else { // Not a rich notification, just display the simple message
			console.log("checkForMessages show simple notification");
			  showSimpleMsg(notification);
		     }
		} else {
		    console.log("No new message") ;
		}
    }, function onError(error) {
	    console.log("checkForMessages ERROR:"+error);
    });
}

