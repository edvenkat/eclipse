var myApp = new Framework7();
 
var $$ = Dom7;


var mainView = myApp.addView('.view-main', {
    // Because we want to use dynamic navbar, we need to enable it for this view:
    dynamicNavbar: false
});

$(function () {
	//alert("test")
	//profile swiper
	var galleryTop = new Swiper('.gallery-top', {
		nextButton: '.swiper-button-next',
		prevButton: '.swiper-button-prev',
		spaceBetween: 10,
		autoHeight: 'true',
		onSlideChangeStart : function(swiper) {
			$(".gap").removeClass('swiper-slide-active_1');
			$("#id_"+swiper.activeIndex).addClass('swiper-slide-active_1');
		}
	});
	var galleryThumbs = new Swiper('.gallery-thumbs', {
		freeMode:true,
		freeModeSticky:true,
		freeModeMomentumVelocityRatio:0.2,
		spaceBetween: 30,
		centeredSlides: true,
		slidesPerView: 'auto',
		touchRatio: 0.2,
		slideToClickedSlide: true,
		onClick:function(swiper, event) {
			galleryTop.slideTo(swiper.activeIndex);
		}
	});
	galleryTop.params.control = galleryThumbs;
	//galleryThumbs.params.control = galleryTop;
});

myApp.onPageInit('ip_page', function (page) {
var myPhotoBrowserStandalone = myApp.photoBrowser({
    photos : [
        'img/unis/images/uni_glyndwr.png',
        'img/unis/images/uni_bangor.png',
        'img/unis/images/uni_huddersfield.png',
    ],
    theme: 'dark'
});
//Open photo browser on click
$$('.photo').on('click', function () {
    myPhotoBrowserStandalone.open();
});
// Photo Browser



//profile swiper
var galleryTop = new Swiper('.gallery-top', {
            nextButton: '.swiper-button-next',
            prevButton: '.swiper-button-prev',
            spaceBetween: 10,
            autoHeight: 'true'
        });
        var galleryThumbs = new Swiper('.gallery-thumbs', {
            spaceBetween: 30,
            centeredSlides: true,
            slidesPerView: 'auto',
            touchRatio: 0.2,
            slideToClickedSlide: true
        });
        galleryTop.params.control = galleryThumbs;
        galleryThumbs.params.control = galleryTop;
});

myApp.onPageInit('pr_page', function (page) {
  /* document.addEventListener("deviceready", onDeviceReady, false);

function onDeviceReady() {
    if (device.platform === 'iOS' && parseFloat(device.version) >= 7.0) {                    
    StatusBar.overlaysWebView(false);
    StatusBar.backgroundColorByName('');
    StatusBar.styleBlackTranslucent();
  }  

}*/

});
myApp.onPageInit('accomadation', function (page) {
    // Do something here for "about" page

});
myApp.onPageInit('data', function (page) {
    // Do something here for "about" page

});

























$$('.open-index').on('click', function () {
  myApp.popup('.popup-index');
});


$$('.open-qual').on('click', function () {
  myApp.popup('.popup-qual');
});
$$('.cls1').on('click', function(){
    myApp.closeModal('.popup-qual');
});
$$('.open-subject').on('click', function () {
  myApp.popup('.popup-subject');
});
$$('.cls2').on('click', function(){
    myApp.closeModal('.popup-subject');
});
// For University filter
$$('.open-university').on('click', function () {
  myApp.popup('.popup-university');
});
$$('.cls3').on('click', function(){
    myApp.closeModal('.popup-university');
});

// For Location type
$$('.open-ltype').on('click', function () {
  myApp.popup('.popup-ltype');
});
$$('.cls4').on('click', function(){
    myApp.closeModal('.popup-ltype');
});

//For best match
$$('.open-best').on('click', function () {
  myApp.popup('.popup-best');
});
$$('.cls5').on('click', function(){
    myApp.closeModal('.popup-best');
});
//For Prvious study
$$('.open-pstudy').on('click', function () {
  myApp.popup('.popup-pstudy');
});
$$('.cls6').on('click', function(){
    myApp.closeModal('.popup-pstudy');
});
//For Graduate salery
$$('.open-gsalery').on('click', function () {
  myApp.popup('.popup-gsalery');
});
$$('.cls7').on('click', function(){
    myApp.closeModal('.popup-gsalery');
});

//For How you study
$$('.open-howstudy').on('click', function () {
  myApp.popup('.popup-howstudy');
});
$$('.cls8').on('click', function(){
    myApp.closeModal('.popup-howstudy');
});
//For Location
$$('.open-location').on('click', function () {
  myApp.popup('.popup-location');
});
$$('.cls9').on('click', function(){
    myApp.closeModal('.popup-location');
});
//For Qualification tooltip
$$('.open-qualttip').on('click', function () {
  myApp.popup('.popup-qualttip');
  this.addClass('flip')
});
$$('.cls10').on('click', function(){
    myApp.closeModal('.popup-qualttip');
});

//For Qualification tooltip
$$('.open-howttip').on('click', function () {
  myApp.popup('.popup-howttip');
});
$$('.cls11').on('click', function(){
    myApp.closeModal('.popup-howttip');
});












//For Job Prospectus
$$('.open-job').on('click', function () {
  myApp.popup('.popup-job');
});
$$('.clsjp').on('click', function(){
    myApp.closeModal('.popup-job');
});

//For Job Prospectus
$$('.open-accomadation').on('click', function () {
  myApp.popup('.popup-accomadation');
});
$$('.clsac').on('click', function(){
    myApp.closeModal('.popup-accomadation');
});









//Arul for Flip
$$('.clk_im').on('click', function(){
$(this).parents('.popup-qual').removeClass('flip-out');
$(this).parents('.popup-qual').addClass('flip-in');
});

$$('.popup-qualttip .back').on('click', function(){
$(this).parents('body').find('.popup-qual').removeClass('flip-in');
//$(this).parents('body').find('.popup-qual').addClass('flip-out');

});



